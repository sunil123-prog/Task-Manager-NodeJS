This is a NodeJS project.
This project is based on Task Manager Application.
Tech Stack -
1. NodeJS
2. ExpressJS
3. MongoDB
4. HTML
5. CSS
6. Bootstrap
